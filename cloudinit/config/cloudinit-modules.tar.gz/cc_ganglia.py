#################################################################################
# Author: Cristovao Cordeiro <cristovao.cordeiro@cern.ch>			#
#										#
# Cloud Config module for Ganglia service. Testes and working on SLC6 machines. #
# Documentation in:								#
# https://twiki.cern.ch/twiki/bin/view/LCG/CloudInit				#
#################################################################################

import subprocess
try:
  import cloudinit.CloudConfig as cc
except ImportError:
  import cloudinit.config as cc
except:
  print "There is something wrong with this module installation. Please verify and rerun."
  import sys
  sys.exit(0)

import urllib
import socket
import re
import sys


# In case this runs to early during the boot, the PATH environment can still be unset. Let's define each necessary command's path
# Using subprocess calls so it raises exceptions directly from the child process to the parent
YUM_cmd = '/usr/bin/yum'
HOST_cmd = '/bin/hostname'
SERVICE_cmd = '/sbin/service'
GMOND_cmd = '/etc/init.d/gmond'
SETSE_cmd = '/usr/sbin/setsebool'
CHKCONFIG = '/sbin/chkconfig'


def conf_node(node_f, params, lines):
  flocal_new = open(node_f, 'w')     # Open the gmond file, but let's overwrite it with the new variables
  if 'globals' in params:
    globals_cfg = params['globals']
    for param, value in globals_cfg.iteritems():
      if param == 'daemonize':
        for i in range(0,len(lines)):
          if 'daemonize' in lines[i]:
            lines[i] = "  daemonize = "+str(value)+'\n'
            break
      if param == 'setuid':
        for i in range(0,len(lines)):
          if 'setuid' in lines[i]:
            lines[i] = "  setuid = "+str(value)+'\n'
            break
      if param == 'user':
        for i in range(0,len(lines)):
          if 'user = ' in lines[i]:
            lines[i] = "  user = "+str(value)+'\n'
            break
      if param == 'debug-level':
        for i in range(0,len(lines)):
          if 'debug_level' in lines[i]:
            lines[i] = "  debug_level = "+str(value)+'\n'
            break
      if param == 'max-udp-msg-len':
        for i in range(0,len(lines)):
          if 'max_udp_msg_len' in lines[i]:
            lines[i] = "  max_udp_msg_len = "+str(value)+'\n'
            break
      if param == 'mute':
        for i in range(0,len(lines)):
          if 'mute' in lines[i]:
            lines[i] = "  mute = "+str(value)+'\n'
            break
      if param == 'deaf':
        for i in range(0,len(lines)):
          if 'deaf' in lines[i]:
            lines[i] = "  deaf = "+str(value)+'\n'
            break
      if param == 'allow-extra-data':
        for i in range(0,len(lines)):
          if 'allow_extra_data' in lines[i]:
            lines[i] = "  allow_extra_data = "+str(value)+'\n'
            break
      if param == 'host-dmax':
        for i in range(0,len(lines)):
          if 'host_dmax' in lines[i]:
            lines[i] = "  host_dmax = "+str(value)+' /*secs */\n'
            break
      if param == 'cleanup-threshold':
        for i in range(0,len(lines)):
          if 'cleanup_threshold' in lines[i]:
            lines[i] = "  cleanup_threshold = "+str(value)+' /*secs */\n'
            break
      if param == 'gexec':
        for i in range(0,len(lines)):
          if 'gexec = ' in lines[i]:
            lines[i] = "  gexec = "+str(value)+'\n'
            break
      if param == 'send-metadata-interval':
        for i in range(0,len(lines)):
          if 'send_metadata_interval' in lines[i]:
            lines[i] = "  send_metadata_interval = "+str(value)+' /*secs */\n'
            break
  # End of globals configuration
  
  if 'cluster' in params:
    cluster_cfg = params['cluster']
    for i in range(0,len(lines)):   # Optimization to find where cluster starts instead of reading file from top every time
      if 'cluster {' in lines[i]:
        indice = i
        break
    for param, value in cluster_cfg.iteritems():
      if param == 'name':
        for l in range(indice,len(lines)):
          if 'name' in lines[l]:
            lines[l] = "  name = "+str(value)+'\n'
            break
      if param == 'owner':
        for l in range(indice,len(lines)):
          if 'owner' in lines[l]:
            lines[l] = "  owner = "+str(value)+'\n'
            break
      if param == 'latlong':
        for l in range(indice,len(lines)):
          if 'latlong' in lines[l]:
            lines[l] = "  latlong = "+str(value)+'\n'
            break
      if param == 'url':
        for l in range(indice,len(lines)):
          if 'url' in lines[l]:
            lines[l] = "  url = "+str(value)+'\n'
            break

  # End of cluster configuration

  lines = [word.replace('mcast_join','host') for word in lines]               # Change to 'host' instead of 'mcast_join'. If it isn't passed in cloud-config, it will be changed anyway.

  for i in range(0,len(lines)):
    if 'udp_recv_channel {' in lines[i]:
      indice_aux = i
      break
  for u in range(indice_aux, indice_aux+10):    # Erase the 'host' parameter in udp_recv_channel, because it causes parsing errors
    if 'host' in lines[u]:
      lines[u] = ''
      break

  if 'udpSendChannel' in params:
    udp_send_cfg = params['udpSendChannel']
    for i in range(0,len(lines)):   # Same process as cluster
      if 'udp_send_channel {' in lines[i]:
        indice_udp = i
        break
    for param, value in udp_send_cfg.iteritems():
      if param == 'host':
        for a in range(indice_udp, len(lines)):
          if 'host = ' in lines[a]:
            lines[a] = "  host = "+str(value)+'\n'
            break
      if param == 'port':
        for a in range(indice_udp, len(lines)):
          if 'port' in lines[a]:
            lines[a] = "  port = "+str(value)+'\n'
            break
      if param == 'ttl':
        for a in range(indice_udp, len(lines)):
          if 'ttl' in lines[a]:
            lines[a] = "  ttl = "+str(value)+'\n'
            break
  # End of udp_send_channel configuration

  if 'udpRecvChannel' in params:
    udp_recv_cfg = params['udpRecvChannel']
    for i in range(0,len(lines)):
      if 'udp_recv_channel {' in lines[i]:
        indice_udp_recv = i
        break

    for param, value in udp_recv_cfg.iteritems():
      if param == 'port':
        for u in range(indice_udp_recv, len(lines)):
          if 'port' in lines[u]:
            lines[u] = "  port = "+str(value)+'\n'
            break
      if param == 'bind':
        for u in range(indice_udp_recv, len(lines)):
          if 'bind' in lines[u]:
            lines[u] = "  bind = "+str(value)+'\n'
            break
  # End of udp_recv_channel configuration

  # Finally...
  if 'tcpAcceptChannel' in params:
    tcp_cfg = params['tcpAcceptChannel']
    for i in range(0,len(lines)):
      if 'tcp_accept_channel {' in lines[i]:
        indice_tcp = i
        break
    for param, value in tcp_cfg.iteritems():
      if param == 'port':
        for t in range(indice_tcp, len(lines)):    # tcp_accept_channel is generally small. Five iterations just in case.
          if 'port' in lines[t]:
            lines[t] = "  port = "+str(value)+'\n'
            break
  # End of tcp_accept_channel configuration

  flocal_new.writelines(lines)
  flocal_new.close()
  
  print "End of gmond.conf configuration. Initiating gmond..."

######################
######################

def conf_head(hfile, nfile, param, h_lines, n_lines):
  keys = {'source': '"my servers"',
	  'polling': '15',
	  'address': 'localhost',
	  'port': '8649'}
  
  items = ['source','polling','address','port']
  for word in items:
    if word in param:
      keys[word] = param[word]  

  for h in range(0,len(h_lines)):
    if '#' not in h_lines[h]:
      if 'data_source' in h_lines[h]:
        h_lines[h] = 'data_source '+keys['source']+' '+str(keys['polling'])+' '+keys['address']+':'+str(keys['port'])+'\n'
        break

  # Sometimes, due to some DNS issue it can happen that the full hostname is not resolved, so let's fix hostname as localhost.
  #aux_host = subprocess.Popen(['%s -f' % HOST_cmd], shell=True, stdout=subprocess.PIPE)
  #full_hostname, hosterr = aux_host.communicate()
  #full_hostname = re.sub('\n','',full_hostname)

  for l in range(0,len(n_lines)):
    if 'name = "unspecified"' in n_lines[l]:
      n_lines[l] = '  name = '+keys['source']+'\n'
    if 'mcast_join' in n_lines[l]:
      n_lines[l] = '  host = localhost\n'
    if 'bind = ' in n_lines[l]:
      n_lines[l] = '  #'+str(n_lines[l])+'\n'
    if 'port = ' in n_lines[l]:
      n_lines[l] = '  port = '+str(keys['port'])+'\n'
    if 'ttl = ' in n_lines[l]:
      n_lines[l] = '  #'+str(n_lines[l])+'\n'

  hconf_new = open(hfile, 'w')     # Open the same file, but let's overwrite it with the new variables
  hconf_new.writelines(h_lines)
  hconf_new.close()

  conf_node(nfile,param,n_lines)

######################
######################

def handle(_name, cfg, cloud, log, _args):
  # Always check first if ganglia is referenced in the user-data	
  if 'ganglia' in cfg:
    print "Starting Ganglia setup..."
    # If it reaches this is because ganglia is referenced in user-data
        
    ganglia_cfg = cfg['ganglia']
    print "Installing and configuring Ganglia:"
        
    # Aux variables to know if we are dealing with headnode or node config
    headnode_bool = 0
    node_bool = 0        

    if 'nodes' in ganglia_cfg and 'headnode' in ganglia_cfg:
      print "ATTENTION: you can not configure a ganglia node and a ganlgia head node on the same machine!\nSkipping ganglia configuration..."
      return
        
    Installation = False
    if 'install' in ganglia_cfg:
      Installation = ganglia_cfg['install']
      if Installation == True:
        subprocess.check_call([YUM_cmd,'-y','install','ganglia','ganglia-gmond'])
        
  # If ganglia-gmetad and ganglia-web are required they should be installed the same way as ganglia and ganglia-gmond
  if 'headnode' in ganglia_cfg:
    # Apache and PHP are required for the ganglia headnode
    if Installation == True:
      subprocess.check_call([YUM_cmd,'-y','install','httpd','php','ganglia-gmetad','ganglia-web'])
    gmetad_conf_file = '/etc/ganglia/gmetad.conf'
    hconf = open(gmetad_conf_file, 'r')
    hlines = hconf.readlines()
    hconf.close()
    ganglia_param_cfg = ganglia_cfg['headnode']
    headnode_bool = 1
  else:
    ganglia_param_cfg = ganglia_cfg['nodes']
    node_bool = 1       

  gmond_conf_file = '/etc/ganglia/gmond.conf'
  flocal = open(gmond_conf_file, 'r')     # Open to read all the file and then close it
  node_lines = flocal.readlines()
  flocal.close()
        
  # Let start by changing the configuration on the collector server, in case headnode is referenced
  if headnode_bool:
    conf_head(gmetad_conf_file, gmond_conf_file, ganglia_param_cfg, hlines, node_lines)
    
  if node_bool:
    conf_node(gmond_conf_file, ganglia_param_cfg, node_lines)
        

  # Stop iptables to solve connectivity issues. Configuring iptables would be a better solution
  subprocess.check_call([SERVICE_cmd,'iptables','stop'])
    
  subprocess.call([SETSE_cmd,'httpd_can_network_connect','1'])
           
  subprocess.check_call([GMOND_cmd,'restart'])        

  subprocess.call([CHKCONFIG,'gmond','on'])

  if headnode_bool:
    # Starting and configuring Apache
           
    NewLine = '    Allow from cern.ch\n  </Location>\n'
    httpdf = open('/etc/httpd/conf.d/ganglia.conf','r')
    oldlines = httpdf.readlines()
    for l in range(0,len(oldlines)):
      if '</Location>' in oldlines[l]:
        oldlines[l] = NewLine

    httpdf.close()
    httpdf_write = open('etc/httpd/conf.d/ganglia.conf','w')
    httpdf_write.writelines(oldlines)
    httpdf_write.close()      
        
    subprocess.check_call([SERVICE_cmd,'httpd','restart'])
    subprocess.check_call([SERVICE_cmd,'gmetad','restart'])


##### END #####
